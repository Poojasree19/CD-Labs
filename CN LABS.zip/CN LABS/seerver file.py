import socket
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
host=socket.gethostname()
port=9947
s.bind((host,port))
s.listen(5)
print("waiting for client to start")

while True:
    c,add=s.accept()
    data=c.recv(1024)
    print(data.decode())
    f=open("myfile.txt","rb")
    m=f.read(1024)
    while(m):
        print(c.send(bytes(str(m),'utf-8')))
        m=f.read(1024)
    f.close()
    print("successfully sent")
    c.send(bytes('connected successfully', 'utf-8'))
    c.close()