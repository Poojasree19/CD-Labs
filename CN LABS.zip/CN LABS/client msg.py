#receiver or client side
import socket
clt=socket.socket(family=socket.AF_INET,type=socket.SOCK_STREAM)
clt1=('localhost',8898)
clt.connect(clt1)

name = input("Enter your name\n")
clt.send(bytes(name,'utf-8'))
print(clt.recv(1025).decode())

message =input("Enter message:\n")
#print("send to server",message)
clt.send(bytes(str(message),'utf-8'))
print("original message",message)

data=clt.recv(1000).decode()
print (data)