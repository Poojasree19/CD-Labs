#server side UDP
import socket
sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
host = socket.gethostname()
port = 8677
sock.bind((host,port))
print("Waiting for client to start.......")
data,addr = sock.recvfrom(1024)
print("Received Messages:",data," from",addr)