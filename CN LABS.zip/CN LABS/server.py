#server side
import socket
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
host=socket.gethostname()
port=8999
s.bind((host,port))
s.listen(5)
print ("socket is listening")

while True:
    c,addr = s.accept()
    print("Got address from", addr)
    c.send("........WELCOME.......\nThank you for connecting".encode())
    c.close()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
