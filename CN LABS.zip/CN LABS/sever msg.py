#server side or sender
import socket
server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server_address=('localhost',8898)
server.bind(server_address)
server.listen(1)
print("waiting for the connection")
while True:
    clt,client_address=server.accept()
    name=clt.recv(1025).decode()
    print("connection established",client_address,name)
    clt.send(bytes("welcome to the connection",'utf-8'))
    data=clt.recv(1000)
    print("Data received",data)
    clt.close()