x=list(map(int,input("Enter the ip address: ").split('.')))

if (x[0]>=0 and x[0]<=127):
    print("CLASS A")
    print("Network ID:",x[0],".0.0.0")
    print("Broadcast ID:",x[0],".255.255.255")
    h = (2 ** 24) - 3
    print("Max number of hosts =", h)
elif(x[0]>=128 and x[0]<=191):
    print("CLASS B")
    print("Network ID:", x[0],x[1],".0.0")
    print("Broadcast ID:", x[0],x[2],".255.255")
    h = (2 ** 16) - 3
    print("Max number of hosts =", h)
elif(x[0]>=192 and x[0]<=223):
    print("CLASS C")
    print("Network ID:", x[0],x[1],x[2], ".0")
    print("Broadcast ID:", x[0],x[1],x[2],".255")
    h = (2 ** 8) - 3
    print("Max number of hosts =", h)
else:
    print("CLASS D or E")

