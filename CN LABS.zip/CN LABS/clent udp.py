#client side UDP
import socket
sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
host = socket.gethostname()

port = 8677

msg = "Dinesh"
msg=str.encode(msg)
#print("UDP target IP:", host)
#print("UDP target Port:", port)
sock.sendto(msg,(host,port))
print("message sent")