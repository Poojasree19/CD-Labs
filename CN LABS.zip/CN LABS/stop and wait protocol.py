import socket
from threading import Thread
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
host=socket.gethostname()
port=9455
s.bind((host,port))

class client(Thread):
    def __init__(self, socket, address):
        Thread.__init__(self)
        self.sock = socket
        self.addr = address
        self.start()

    def run(self):
        while 1:
            n = int(input("Enter the frame size: "))
            for i in range (0,n):
                r=input("Send data -->")
                c.send(r.encode())
                print(c.recv(1025).decode())
            break
s.listen(5)
print("Server is ready now")
while True:
    c,add=s.accept()
    print("client got connected")
    client(c,add)