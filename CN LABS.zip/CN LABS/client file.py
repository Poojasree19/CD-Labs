import socket
c=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
host=socket.gethostname()
port=9947
c.connect((host,port))
c.send(bytes('hi server','utf-8'))

with open("myfile.txt","wb") as f:
    print("File has opened")
    while True:
        data=c.recv(1024)
        print(data)
        if not data:
            break
        f.write(data)
f.close()
print("Get the file now")
c.close()
print("connection closed")