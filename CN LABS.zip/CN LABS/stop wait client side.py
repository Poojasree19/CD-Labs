import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host =socket.gethostname()
port =9455
s.connect((host,port))
print("waiting for the frame")
arr=['1','2']

while 1:
   data=s.recv(1025).decode()
   print("Received --> "+data)
   for i in range (2):
      if (data in arr[i]):
         str="Acknowledgement: Message Received"
         s.send(str.encode())
      else:
         st="re transmit data"
         s.send(st.encode())

   print("Data received")
s.close ()